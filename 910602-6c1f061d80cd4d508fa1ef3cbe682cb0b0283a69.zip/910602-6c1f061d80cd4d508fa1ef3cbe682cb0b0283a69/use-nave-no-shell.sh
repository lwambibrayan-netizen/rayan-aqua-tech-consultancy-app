# use nave, but without a subshell
# note that we're doing "usemain" instead of "use"

mkdir ~/.nave
cd ~/.nave
wget http://github.com/isaacs/nave/raw/master/nave.sh
sudo ln -s $PWD/nave.sh /usr/local/bin/nave

# take ownership
# please don't do this if you don't know what it does!
sudo chown -R $USER /usr/local/{share/man,bin,lib/node}

# install the latest stable nodejs in the "main" root.
nave usemain stable

curl http://npmjs.org/install.sh | sh
