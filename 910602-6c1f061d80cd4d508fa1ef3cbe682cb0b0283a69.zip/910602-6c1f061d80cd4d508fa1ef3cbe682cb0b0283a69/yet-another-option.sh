# install node wherever.
# use sudo even, it doesn't matter
# we're telling npm to install in a different place.
cat <<NPMRC >>$HOME/.npmrc
root = ~/.node_libraries
manroot = ~/local/share/man
binroot = ~/bin
NPMRC
curl http://npmjs.org/install.sh | sh
