# RayanAqua Tech Consultancy

React + Vite starter repository for a professional water-engineering design workspace.

## Requirements
- Node.js 20.19+ or 22.12+
- npm

## Run locally
```bash
npm install
npm run dev
```
Open the local URL printed by Vite.

## Production build
```bash
npm run build
npm run preview
```

## GitHub upload
1. Extract this ZIP.
2. Create a new GitHub repository named `rayanaqua-tech-consultancy`.
3. Upload the **contents** of the extracted folder (not the ZIP itself).
4. Commit to the `main` branch.
5. In Vercel, import the GitHub repository. Framework: Vite; build command: `npm run build`; output directory: `dist`.

## Engineering modules
- `src/modules/calculators`: demand and preliminary pipe sizing calculations.
- `src/modules/gis`: GIS workspace boundary and integration adapter.
- `src/modules/epanet`: EPANET engine adapter contract and project interchange points.
- `src/modules/projects`: local project save/open/clone workspace.
- `src/components`: reusable interface components.

## Important engineering status
This repository is a clean, npm-installable application foundation. It includes a working dashboard, preliminary calculators, local project workspace, and module interfaces. It does **not** claim to contain a full EPANET solver, QGIS processing engine, surveyed terrain/elevation service, CAD kernel, production authentication, or multi-user database isolation yet. Those require their respective engines/services and must be integrated and tested before using outputs for real designs.

The pipe-sizing helper is a preliminary continuity calculation only. It does not replace hydraulic network simulation, transient analysis, code checks, survey data, geotechnical investigation, or professional design review.

## Security
Do not place database service-role keys or private API credentials in frontend environment variables. Enforce tenant isolation in the backend/database with row-level security and server-side authorization before enabling multi-user use.
