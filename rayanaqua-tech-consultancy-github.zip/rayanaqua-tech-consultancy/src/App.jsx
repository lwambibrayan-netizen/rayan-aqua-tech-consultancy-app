import { useMemo, useState } from 'react'
import { Activity, Calculator, ChevronRight, CircleHelp, ClipboardList, Database, Droplets, FolderOpen, Gauge, GitBranch, Map, Plus, Save, Waves } from 'lucide-react'
import Metric from './components/Metric.jsx'
import { calculateDailyDemand, calculatePipeDiameter, assessVelocity } from './modules/calculators/hydraulics.js'
import { listProjects, saveProject, cloneProject, deleteProject } from './modules/projects/projectStore.js'
import { epanetStatus } from './modules/epanet/epanetAdapter.js'
import { gisCapabilities } from './modules/gis/gisAdapter.js'

const initialProject = { name: 'Untitled water supply project', location: 'Taita Taveta, Kenya', notes: '', network: { nodes: [], links: [] } }

export default function App() {
  const [section, setSection] = useState('Overview')
  const [project, setProject] = useState(initialProject)
  const [projects, setProjects] = useState(listProjects())
  const [population, setPopulation] = useState('25000')
  const [lpcd, setLpcd] = useState('50')
  const [allowance, setAllowance] = useState('15')
  const [flow, setFlow] = useState('10')
  const [velocity, setVelocity] = useState('1.2')
  const [notice, setNotice] = useState('')
  const demand = useMemo(() => calculateDailyDemand(population, lpcd, allowance), [population, lpcd, allowance])
  const pipe = useMemo(() => calculatePipeDiameter(flow, velocity), [flow, velocity])
  const velocityCheck = assessVelocity(velocity)

  const refresh = () => setProjects(listProjects())
  const save = () => { const p = saveProject(project); setProject(p); refresh(); setNotice('Project saved in this browser.') }
  const open = p => { setProject(p); setSection('Project Workspace'); setNotice(`Opened ${p.name}`) }
  const nav = [
    ['Overview', Activity], ['Project Workspace', FolderOpen], ['GIS Design', Map], ['EPANET Analysis', Waves],
    ['Engineering Calculators', Calculator], ['Reports & Documents', ClipboardList]
  ]
  return <div className="shell">
    <aside className="sidebar">
      <div className="brand"><div className="brand-mark"><Droplets size={23}/></div><div><b>RayanAqua</b><small>TECH CONSULTANCY</small></div></div>
      <div className="workspace-label">ENGINEERING WORKSPACE</div>
      <nav>{nav.map(([label, Icon]) => <button key={label} className={section === label ? 'active' : ''} onClick={() => setSection(label)}><Icon size={18}/><span>{label}</span><ChevronRight size={15}/></button>)}</nav>
      <div className="sidebar-bottom"><div className="status-dot"/> Engineering platform foundation <small>Version 1.0.0</small></div>
    </aside>
    <main className="main">
      <header className="topbar"><div><span className="eyebrow">RAYANAQUA / ENGINEERING</span><h1>{section}</h1></div><div className="top-actions"><span className="local-tag">LOCAL WORKSPACE</span><button className="primary small" onClick={save}><Save size={16}/> Save project</button></div></header>
      {notice && <div className="notice" onClick={() => setNotice('')}>{notice} <span>×</span></div>}
      {section === 'Overview' && <><section className="welcome"><div><span className="eyebrow light">WATER ENGINEERING • DESIGN • DELIVERY</span><h2>Design water systems<br/>with engineering clarity.</h2><p>A central workspace for water supply planning, network design, hydraulic checks and project documentation.</p><button className="light-button" onClick={() => setSection('Project Workspace')}><Plus size={16}/> Start a project</button></div><div className="water-art"><div className="ring ring1"/><div className="ring ring2"/><Waves size={100}/></div></section>
        <div className="metrics"><Metric label="SAVED PROJECTS" value={projects.length} hint="Stored in this browser"/><Metric label="GIS ENGINE" value="Adapter ready" hint="Terrain service not connected"/><Metric label="EPANET ENGINE" value="Not connected" hint="Solver integration required"/><Metric label="CALCULATORS" value="Available" hint="Preliminary design tools"/></div>
        <div className="section-heading"><div><span className="eyebrow">YOUR WORKBENCH</span><h3>Engineering modules</h3></div></div><div className="module-grid">
          <Module icon={<Map/>} title="GIS Design" desc="Prepare spatial network drafts and connect terrain elevation data." action={() => setSection('GIS Design')} tag="Integration pending"/>
          <Module icon={<Waves/>} title="EPANET Analysis" desc="Prepare network models for hydraulic simulation and validation." action={() => setSection('EPANET Analysis')} tag="Solver pending"/>
          <Module icon={<Calculator/>} title="Engineering Calculators" desc="Calculate demand, preliminary pipe diameter and velocity checks." action={() => setSection('Engineering Calculators')} tag="Available"/>
          <Module icon={<FolderOpen/>} title="Project Workspace" desc="Save, reopen and clone engineering project drafts." action={() => setSection('Project Workspace')} tag="Available"/>
        </div></>}
      {section === 'Engineering Calculators' && <div className="content-grid"><div className="panel"><h3><Droplets/> Water demand calculator</h3><p className="muted">Preliminary average daily demand estimate.</p><Field label="Population" value={population} set={setPopulation}/><Field label="Per-capita demand (L/person/day)" value={lpcd} set={setLpcd}/><Field label="Allowance (%)" value={allowance} set={setAllowance}/><div className="result"><span>Estimated daily demand</span><b>{demand.cubicMetresPerDay.toLocaleString(undefined,{maximumFractionDigits:2})} m³/day</b><small>{demand.litresPerDay.toLocaleString(undefined,{maximumFractionDigits:0})} litres/day</small></div></div><div className="panel"><h3><Gauge/> Preliminary pipe sizing</h3><p className="muted">Continuity equation: Q = A × V. Does not include headloss or network effects.</p><Field label="Flow (m³/hour)" value={flow} set={setFlow}/><Field label="Target velocity (m/s)" value={velocity} set={setVelocity}/><div className="result"><span>Calculated internal diameter</span><b>{pipe.diameterMm.toFixed(1)} mm</b><small>{pipe.diameterM.toFixed(4)} m · theoretical diameter</small></div><div className={`check ${velocityCheck.status === 'PASS' ? 'pass' : 'warn'}`}><b>{velocityCheck.status}</b><span>{velocityCheck.message} Selected screening range: 0.6–1.5 m/s; adjust to applicable design criteria.</span></div></div></div>}
      {section === 'Project Workspace' && <div className="content-grid"><div className="panel"><h3><FolderOpen/> Project details</h3><Field label="Project name" value={project.name} set={v => setProject({...project,name:v})}/><Field label="Location" value={project.location} set={v => setProject({...project,location:v})}/><label className="field"><span>Project notes</span><textarea value={project.notes || ''} onChange={e => setProject({...project,notes:e.target.value})} placeholder="Scope, design basis, assumptions..."/></label><button className="primary" onClick={save}><Save size={16}/> Save project</button></div><div className="panel"><h3><Database/> Saved projects</h3>{projects.length === 0 ? <p className="muted">No saved projects yet. Save the current project to see it here.</p> : projects.map(p => <div className="project-row" key={p.id}><button className="project-open" onClick={() => open(p)}><b>{p.name}</b><small>{p.location || 'No location'} · {new Date(p.updatedAt).toLocaleDateString()}</small></button><button className="icon-btn" title="Clone project" onClick={() => {cloneProject(p.id);refresh()}}>Clone</button><button className="icon-btn danger" title="Delete project" onClick={() => {deleteProject(p.id);refresh()}}>×</button></div>)}</div></div>}
      {section === 'GIS Design' && <div className="panel full-panel"><h3><Map/> GIS network design</h3><div className="status-banner"><CircleHelp/> GIS drawing and terrain elevation are not connected in this starter repository.</div><p className="muted">The GIS adapter is prepared for integration. A production GIS module should use a real map engine, coordinate reference systems, geospatial storage, surveyed/authoritative terrain elevation, and validated export mapping to EPANET. Basemap display alone must never be treated as actual ground elevation.</p><div className="capability-list">{Object.entries(gisCapabilities).map(([k,v]) => <div key={k}><span>{k.replaceAll(/([A-Z])/g,' $1')}</span><b>{v}</b></div>)}</div></div>}
      {section === 'EPANET Analysis' && <div className="panel full-panel"><h3><Waves/> EPANET hydraulic analysis</h3><div className="status-banner"><CircleHelp/> EPANET solver is not connected. No simulation has been run.</div><p className="muted">This module provides the integration boundary for a genuine EPANET 2.2-compatible engine. The completed integration must support nodes, reservoirs, tanks, pipes, pumps, valves, patterns, controls, .INP import/export, pressure and velocity criteria, warnings and solver results.</p><div className="capability-list"><div><span>Engine status</span><b>{epanetStatus.engine}</b></div><div><span>Simulation</span><b>{epanetStatus.simulation}</b></div><div><span>File format</span><b>.INP — integration required</b></div></div></div>}
      {section === 'Reports & Documents' && <div className="panel full-panel"><h3><ClipboardList/> Reports & engineering documentation</h3><p className="muted">Reporting module foundation. Future reports should capture project metadata, design criteria, assumptions, source data, calculation sheets, GIS maps, EPANET results, revision history and approval status.</p><div className="status-banner">Report generation is not yet connected to calculation and simulation engines.</div></div>}
      <footer>RayanAqua Tech Consultancy <span>Engineering decisions must be verified against project data and applicable standards.</span></footer>
    </main>
  </div>
}

function Module({icon,title,desc,action,tag}) { return <button className="module-card" onClick={action}><div className="module-icon">{icon}</div><span className="module-tag">{tag}</span><h4>{title}</h4><p>{desc}</p><span className="module-link">Open module <ChevronRight size={15}/></span></button> }
function Field({label,value,set}) { return <label className="field"><span>{label}</span><input value={value} onChange={e=>set(e.target.value)} /></label> }
