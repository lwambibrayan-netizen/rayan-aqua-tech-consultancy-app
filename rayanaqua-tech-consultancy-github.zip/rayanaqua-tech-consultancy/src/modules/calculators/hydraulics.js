// Preliminary engineering helpers. Validate assumptions and design criteria before use.
export function calculateDailyDemand(population, lpcd, allowancePercent = 0) {
  const p = Number(population), q = Number(lpcd), a = Number(allowancePercent)
  if (![p, q, a].every(Number.isFinite) || p < 0 || q < 0 || a < 0) throw new Error('Enter valid non-negative values.')
  const litresPerDay = p * q * (1 + a / 100)
  return { litresPerDay, cubicMetresPerDay: litresPerDay / 1000 }
}

export function calculatePipeDiameter(flowM3h, velocityMs) {
  const q = Number(flowM3h) / 3600
  const v = Number(velocityMs)
  if (!Number.isFinite(q) || !Number.isFinite(v) || q <= 0 || v <= 0) throw new Error('Flow and velocity must be greater than zero.')
  const diameterM = Math.sqrt((4 * q) / (Math.PI * v))
  return { diameterM, diameterMm: diameterM * 1000, areaM2: q / v }
}

export function assessVelocity(velocity, min = 0.6, max = 1.5) {
  const v = Number(velocity)
  if (!Number.isFinite(v)) return { status: 'INVALID', message: 'Enter a valid velocity.' }
  if (v < min) return { status: 'LOW', message: `Below the selected minimum of ${min} m/s.` }
  if (v > max) return { status: 'HIGH', message: `Above the selected maximum of ${max} m/s.` }
  return { status: 'PASS', message: `Within the selected range (${min}–${max} m/s).` }
}
