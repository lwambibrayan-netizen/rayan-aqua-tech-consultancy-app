// EPANET engine boundary.
// Integrate a real EPANET 2.2-compatible WASM/native engine here.
// This module deliberately does not fabricate hydraulic simulation results.
export const epanetStatus = {
  engine: 'not-installed',
  supportedFormats: ['.inp (integration required)'],
  simulation: 'not-available-until-engine-is-integrated'
}

export async function runHydraulicSimulation(_model) {
  throw new Error('EPANET solver is not connected yet. Integrate and validate an EPANET 2.2 engine before running simulations.')
}

export function exportInp(_model) {
  throw new Error('EPANET .inp export adapter is not connected yet.')
}

export function importInp(_file) {
  throw new Error('EPANET .inp parser is not connected yet.')
}
