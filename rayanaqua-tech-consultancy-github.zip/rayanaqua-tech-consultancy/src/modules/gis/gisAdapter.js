// GIS integration boundary.
// Connect a real mapping/terrain provider here. Do not treat basemap pixels as surveyed elevations.
export const gisCapabilities = {
  mapDisplay: 'planned',
  drawing: 'planned',
  terrainElevation: 'not-connected',
  spatialAnalysis: 'not-connected',
  exportToEpanet: 'adapter-required'
}

export function toEpanetDraft(gisNetwork) {
  // Convert validated GIS nodes/links into an EPANET-compatible draft model.
  // A real implementation must map elevations, demands, lengths, diameters,
  // roughness, statuses, reservoirs, tanks, pumps and valves with units checked.
  if (!gisNetwork || !Array.isArray(gisNetwork.nodes) || !Array.isArray(gisNetwork.links)) {
    throw new Error('GIS network must contain nodes and links.')
  }
  return { nodes: gisNetwork.nodes, links: gisNetwork.links, source: 'GIS draft' }
}
