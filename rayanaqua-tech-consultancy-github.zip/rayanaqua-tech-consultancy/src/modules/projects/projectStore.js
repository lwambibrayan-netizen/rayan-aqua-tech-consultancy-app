const KEY = 'rayanaqua.projects.v1'
const read = () => {
  try { return JSON.parse(localStorage.getItem(KEY) || '[]') } catch { return [] }
}
const write = items => localStorage.setItem(KEY, JSON.stringify(items))

export function listProjects() { return read() }
export function saveProject(project) {
  const items = read()
  const now = new Date().toISOString()
  const item = { ...project, id: project.id || crypto.randomUUID(), updatedAt: now, createdAt: project.createdAt || now }
  const index = items.findIndex(x => x.id === item.id)
  if (index >= 0) items[index] = item
  else items.unshift(item)
  write(items)
  return item
}
export function cloneProject(id) {
  const source = read().find(x => x.id === id)
  if (!source) throw new Error('Project not found.')
  return saveProject({ ...source, id: undefined, name: `${source.name} (Copy)`, createdAt: undefined })
}
export function deleteProject(id) { write(read().filter(x => x.id !== id)) }
